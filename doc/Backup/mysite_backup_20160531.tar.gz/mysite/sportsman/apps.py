from django.apps import AppConfig

class Config(AppConfig):
    name = 'sportsman'
    verbose_name = "运动能力筛查"
